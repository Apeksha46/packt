@include('web.includes.header')
@yield('content')
@include('web.includes.footer')
