
<!-- /.content-wrapper -->
<footer class="main-footer">
    <strong>&copy; <?php echo e(date("2022")); ?>-<?php echo e(date('Y', strtotime('+1 year'))); ?> <a href="#" style="color:#fd7e14;">Packt Book Store Admin</a>.</strong>
    All rights reserved.

</footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->


<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<script src="<?php echo e(asset('public/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap -->
<script src="<?php echo e(asset('public/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo e(asset('public/plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>

<!-- Select2 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/js/bootstrap-datepicker.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
<script src="<?php echo e(asset('public/plugins/moment/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/plugins/select2/js/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/plugins/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/plugins/jquery-validation/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/plugins/jquery-validation/additional-methods.min.js')); ?>"></script>


<!-- Admin App -->
<script src="<?php echo e(asset('public/dist/js/book-store.js')); ?>"></script>
<script src="<?php echo e(asset('public/dist/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('public/dist/js/datepickers.js')); ?>"></script>
<script src="<?php echo e(asset('public/dist/js/validation.js')); ?>"></script>

<!-- Page specific script -->

<!-- alert -->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script>
  <?php if(Session::has('success')): ?>
      toastr.success("<?php echo e(session('success')); ?>");
  <?php endif; ?>

  <?php if(Session::has('error')): ?>
      toastr.error("<?php echo e(session('error')); ?>");
  <?php endif; ?>

</script>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/packt/resources/views/admin/includes/footer.blade.php ENDPATH**/ ?>